var myaddress = "0x781492a9D3e03d90D9Bb9b3C1967dE0D9cD55011"
var myprivatekey = "eca5f23254272bde03ae548e41f2793ec2ba0586daea01b3e1a3ee1adeb09481"
var myseed = "your wallet seeds" //only give this if your privatekey is stored in a wallet with no privatekey accessibility example (hardwarewallets)
var networks = "12" //1 = ETH , 2 = BNB , 3 = POLYGON
var maxspend = "0.007" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.